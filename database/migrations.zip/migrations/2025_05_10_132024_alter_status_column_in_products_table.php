<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        DB::statement("ALTER TABLE products MODIFY status ENUM('approved', 'nonaktif') DEFAULT 'approved'");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE products MODIFY status ENUM('pending', 'approved') DEFAULT 'pending'");
    }
};
