<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        // Tambah kembali enum 'pending' agar bisa dibersihkan
        DB::statement("ALTER TABLE products MODIFY status ENUM('pending', 'approved', 'nonaktif') DEFAULT 'pending'");
    }

    public function down(): void
    {
        // Jika dibatalkan, kembali ke enum sebelumnya
        DB::statement("ALTER TABLE products MODIFY status ENUM('approved', 'nonaktif') DEFAULT 'approved'");
    }
};
