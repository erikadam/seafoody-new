<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        // 1. Perluas enum dulu agar 'pending' tidak menyebabkan error
        DB::statement("ALTER TABLE products MODIFY status ENUM('pending', 'approved', 'nonaktif') DEFAULT 'pending'");

        // 2. Ubah semua status 'pending' menjadi 'nonaktif'
        DB::table('products')->where('status', 'pending')->update(['status' => 'nonaktif']);

        // 3. Setelah bersih, perketat enum hanya jadi 'approved' dan 'nonaktif'
        DB::statement("ALTER TABLE products MODIFY status ENUM('approved', 'nonaktif') DEFAULT 'approved'");
    }

    public function down(): void
    {
        // Rollback: kembalikan status enum ke kondisi awal
        DB::statement("ALTER TABLE products MODIFY status ENUM('pending', 'approved', 'nonaktif') DEFAULT 'pending'");
    }
};
