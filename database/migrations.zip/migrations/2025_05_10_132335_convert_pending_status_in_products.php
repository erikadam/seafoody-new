<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        // Ubah sementara semua status 'pending' menjadi 'nonaktif'
        DB::table('products')->where('status', 'pending')->update(['status' => 'nonaktif']);
    }

    public function down(): void
    {
        // Jika dibatalkan migrasi, kembalikan lagi ke 'pending'
        DB::table('products')->where('status', 'nonaktif')->update(['status' => 'pending']);
    }
};
