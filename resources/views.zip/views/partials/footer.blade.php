<footer>
    <div class="container text-center">
      <p>&copy; {{ date('Y') }} Seafoody. Menyajikan yang terbaik.</p>
    </div>
  </footer>
