
@extends('layouts.customer')

@section('content')
<div class="container py-4">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4">Dashboard Toko Anda</h2>
        <a href="{{ url('/') }}" class="btn btn-outline-secondary">Kembali ke Home</a>
    </div>

    {{-- Info Toko --}}
    <div class="card mb-4">
        <div class="card-header bg-light fw-bold">Informasi Toko</div>
        <div class="card-body">
            <p><strong>Nama:</strong> {{ Auth::user()->store_name ?? Auth::user()->name }}</p>
            <p><strong>Email:</strong> {{ Auth::user()->email }}</p>
        </div>
    </div>

    {{-- Pesanan Masuk --}}
    <div class="card">
        <div class="card-header bg-light fw-bold">Pesanan Masuk</div>
        <div class="card-body p-0">
            @if($orderItems->count() > 0)
                <table class="table mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Produk</th>
                            <th>Pembeli</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($orderItems as $item)
                            <tr>
                                <td>{{ $item->product->name }}</td>
                                <td>{{ $item->order->user->name }}</td>
                                <td>{{ ucfirst($item->order->status) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @else
                <div class="p-3 text-muted">Belum ada pesanan masuk.</div>
            @endif
        </div>
    </div>

</div>
@endsection
