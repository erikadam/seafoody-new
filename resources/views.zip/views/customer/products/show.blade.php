@extends('layouts.customer')

@section('content')
<div class="container py-4">
    <div class="bg-white shadow rounded-lg p-6">
        <h2 class="text-2xl font-bold mb-4">{{ $product->name }}</h2>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                @if($product->image)
                    <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="rounded shadow w-full h-auto">
                @else
                    <div class="bg-gray-100 border rounded p-6 text-center text-gray-500">Tidak ada gambar</div>
                @endif
            </div>

            <div>
                <p class="text-lg font-semibold mb-2">Harga: <span class="text-indigo-600">Rp{{ number_format($product->price, 0, ',', '.') }}</span></p>
                <p class="mb-2">Stok: {{ $product->stock }}</p>
                <p class="mb-4 text-gray-700">{{ $product->description }}</p>

                <a href="{{ route('products.edit', $product->id) }}" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm">Edit Produk</a>
                <a href="{{ route('products.index') }}" class="ml-3 inline-block text-gray-600 hover:underline text-sm">← Kembali ke Daftar Produk</a>
            </div>
        </div>
    </div>
</div>
@endsection