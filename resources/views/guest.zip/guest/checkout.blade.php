@extends('layouts.guest') {{-- Sesuaikan jika Anda menggunakan layout, kalau tidak bisa hapus baris ini --}}

@section('content')
<div class="container mt-5 mb-5">
  <h2 class="mb-4 text-center">Formulir Pemesanan</h2>

  @if(session('success'))
      <div class="alert alert-success">{{ session('success') }}</div>
  @endif

  @if(session('error'))
      <div class="alert alert-danger">{{ session('error') }}</div>
  @endif

  @if($errors->any())
      <div class="alert alert-danger">
          <ul class="mb-0">
              @foreach($errors->all() as $error)
                  <li>{{ $error }}</li>
              @endforeach
          </ul>
      </div>
  @endif

  <form action="{{ route('guest.checkout.submit') }}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="row">
      <div class="col-md-6 mb-3">
        <label for="buyer_name">Nama Pembeli</label>
        <input type="text" name="buyer_name" class="form-control" id="buyer_name" required value="{{ old('buyer_name') }}">
      </div>

      <div class="col-md-6 mb-3">
        <label for="buyer_phone">Nomor Telepon</label>
        <input type="text" name="buyer_phone" class="form-control" id="buyer_phone" required value="{{ old('buyer_phone') }}">
      </div>

      <div class="col-12 mb-3">
        <label for="buyer_address">Alamat Lengkap</label>
        <textarea name="buyer_address" class="form-control" id="buyer_address" rows="3" required>{{ old('buyer_address') }}</textarea>
      </div>

      <div class="col-md-6 mb-3">
        <label for="product_id">Pilih Produk</label>
        <select name="product_id" id="product_id" class="form-control" required>
            @foreach($products as $product)
              <option value="{{ $product->id }}">{{ $product->name }} - Rp{{ number_format($product->price) }}</option>
            @endforeach
        </select>
      </div>

      <div class="col-md-6 mb-3">
        <label for="quantity">Jumlah</label>
        <input type="number" name="quantity" id="quantity" class="form-control" min="1" required value="{{ old('quantity', 1) }}">
      </div>

      <div class="col-12 mb-3">
        <label for="payment_method">Metode Pembayaran</label>
        <select name="payment_method" id="payment_method" class="form-control" required>
          <option value="cash" {{ old('payment_method') == 'cash' ? 'selected' : '' }}>COD (Bayar di Tempat)</option>
          <option value="transfer" {{ old('payment_method') == 'transfer' ? 'selected' : '' }}>Transfer Bank</option>
        </select>
      </div>

      <div class="col-12 mb-3" id="transferProofSection" style="display: none;">
        <label for="transfer_proof">Upload Bukti Transfer</label>
        <input type="file" name="transfer_proof" id="transfer_proof" class="form-control">
      </div>

      <div class="col-12 text-center">
        <button type="submit" class="btn btn-primary">Kirim Pesanan</button>
      </div>
    </div>
  </form>
</div>

<script>
  document.getElementById('payment_method').addEventListener('change', function () {
      var proofSection = document.getElementById('transferProofSection');
      proofSection.style.display = this.value === 'transfer' ? 'block' : 'none';
  });

  // On page load (restore display if transfer selected)
  window.addEventListener('DOMContentLoaded', function () {
      var method = document.getElementById('payment_method').value;
      document.getElementById('transferProofSection').style.display = method === 'transfer' ? 'block' : 'none';
  });
</script>
@endsection
