@extends('layouts.guest')

@section('content')
<div class="page-heading header-text">
  <div class="container">
    <h1>Checkout</h1>
  </div>
</div>

<div class="container py-5">
  <div class="row">
    {{-- Ringkasan Pesanan --}}
    <div class="col-lg-6">
      <h4 class="mb-3">Ringkasan Pesanan</h4>

      @php $grandTotal = 0; @endphp

      @foreach ($groupedCart as $sellerName => $items)
        <div class="mb-4 border rounded p-3">
          <h6 class="mb-2">Toko: <strong>{{ $sellerName }}</strong></h6>
          <ul class="list-unstyled">
            @foreach ($items as $item)
              @php
                $product  = $item['product'];
                $quantity = $item['quantity'];
                $subtotal = $product->price * $quantity;
                $grandTotal += $subtotal;
              @endphp
              <li class="d-flex align-items-center justify-content-between border-bottom py-2">
                <div class="d-flex align-items-center">
                  <img src="{{ asset('uploads/product/' . $product->image) }}"
                       alt="{{ $product->name }}"
                       class="rounded"
                       style="width:60px;height:60px;object-fit:cover;margin-right:15px;">
                  <div>
                    <div class="fw-bold">{{ $product->name }}</div>
                    <small class="text-muted">Qty: {{ $quantity }}</small>
                  </div>
                </div>
                <div class="text-end fw-semibold">
                  Rp{{ number_format($subtotal, 0, ',', '.') }}
                </div>
              </li>
            @endforeach
          </ul>
        </div>
      @endforeach

      <div class="text-end mt-4">
        <h5>Total:
          <span class="text-primary">Rp{{ number_format($grandTotal, 0, ',', '.') }}</span>
        </h5>
      </div>
    </div>

    {{-- Form Pemesan --}}
    <div class="col-lg-6">
      <h4 class="mb-3">Informasi Pemesan</h4>

      @guest
        <div class="alert alert-warning">
          Silakan <a href="{{ route('login') }}">Login</a> atau
          <a href="{{ route('register') }}">Register</a> terlebih dahulu untuk melanjutkan checkout.
        </div>
      @else
        {{-- Flash dan Validasi Errors --}}
        @if (session('success'))
          <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if (session('error'))
          <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
        @if ($errors->any())
          <div class="alert alert-danger">
            <ul class="mb-0">
              @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        <form action="{{ route('guest.checkout.process') }}"
              method="POST"
              enctype="multipart/form-data">
          @csrf

          <div class="form-group mb-3">
            <label>Nama Lengkap</label>
            <input type="text"
                   name="buyer_name"
                   class="form-control"
                   readonly
                   value="{{ old('buyer_name', Auth::user()->name) }}">
          </div>

          <div class="form-group mb-3">
            <label>Email</label>
            <input type="email"
                   name="buyer_email"
                   class="form-control"
                   readonly
                   value="{{ old('buyer_email', Auth::user()->email) }}">
          </div>

          <div class="form-group mb-3">
            <label>Nomor WhatsApp</label>
            <input type="text"
                   name="buyer_phone"
                   class="form-control"
                   required
                   value="{{ old('buyer_phone') }}">
          </div>

          <div class="form-group mb-3">
            <label>Alamat Lengkap</label>
            <textarea name="buyer_address"
                      rows="3"
                      class="form-control"
                      required>{{ old('buyer_address') }}</textarea>
          </div>

          <div class="form-group mb-3">
            <label>Metode Pembayaran</label><br>
            <div class="form-check form-check-inline">
              <input class="form-check-input"
                     type="radio"
                     name="payment_method"
                     value="cash"
                     {{ old('payment_method', 'cash') !== 'transfer' ? 'checked' : '' }}>
              <label class="form-check-label">COD</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input"
                     type="radio"
                     name="payment_method"
                     value="transfer"
                     {{ old('payment_method') === 'transfer' ? 'checked' : '' }}>
              <label class="form-check-label">Transfer Bank</label>
            </div>
          </div>

          <div id="transfer-proof-section"
               class="form-group mb-3 {{ old('payment_method') === 'transfer' ? '' : 'd-none' }}">
            <div class="alert alert-warning small">
              💳 Silakan transfer ke
              <strong>A.n Rosa - 9999999 (Bank Mandiri)</strong>,
              lalu upload bukti transfer.
            </div>
            <label>Upload Bukti Transfer</label>
            <input type="file" name="transfer_proof" class="form-control">
          </div>

          <div class="text-end mt-4">
            <button type="submit" class="btn btn-primary px-4">
              Proses Checkout
            </button>
          </div>
        </form>
      @endguest
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const radios = document.querySelectorAll('input[name="payment_method"]');
  const proofSection = document.getElementById('transfer-proof-section');

  function toggleProof() {
    if (document.querySelector('input[name="payment_method"]:checked').value === 'transfer') {
      proofSection.classList.remove('d-none');
    } else {
      proofSection.classList.add('d-none');
    }
  }

  radios.forEach(r => r.addEventListener('change', toggleProof));
  toggleProof();
});
</script>
@endsection
