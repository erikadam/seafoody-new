
@extends('layouts.guest')

@section('content')
<div class="container mt-5">
  <div class="card shadow-sm">
    <div class="card-body">
      <h3 class="mb-4 text-center">Status Pesanan Anda</h3>

      <div class="mb-4 text-center">
        <span class="badge 
          @class([
            'bg-warning text-dark' => $order->status === 'in_process_by_customer',
            'bg-info' => $order->status === 'shipped_by_customer',
            'bg-success' => $order->status === 'received_by_buyer',
            'bg-dark' => $order->status === 'completed',
            'bg-secondary' => $order->status === 'waiting_admin_confirmation',
            'bg-primary' => $order->status === 'accepted_by_admin',
            'bg-danger' => $order->status === 'rejected_by_admin',
            'bg-light text-dark' => !in_array($order->status, [
              'in_process_by_customer','shipped_by_customer','received_by_buyer',
              'completed','waiting_admin_confirmation','accepted_by_admin','rejected_by_admin'
            ])
          ])
        ">
          {{ ucwords(str_replace('_', ' ', $order->status)) }}
        </span>
      </div>

      <h5>Informasi Pemesan</h5>
      <p><strong>Nama:</strong> {{ $order->buyer_name }}</p>
      <p><strong>HP:</strong> {{ $order->buyer_phone }}</p>
      <p><strong>Alamat:</strong> {{ $order->buyer_address }}</p>

      <h5 class="mt-4">Detail Pesanan</h5>
      <table class="table table-bordered mt-3">
        <thead>
          <tr>
            <th>Produk</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
          @php $total = 0; @endphp
          @foreach($order->items as $item)
            @php
              $subtotal = $item->price * $item->quantity;
              $total += $subtotal;
            @endphp
            <tr>
              <td>{{ $item->product->name }}</td>
              <td>Rp{{ number_format($item->price) }}</td>
              <td>{{ $item->quantity }}</td>
              <td>Rp{{ number_format($subtotal) }}</td>
            </tr>
          @endforeach
          <tr>
            <td colspan="3" class="text-end"><strong>Total</strong></td>
            <td><strong>Rp{{ number_format($total) }}</strong></td>
          </tr>
        </tbody>
      </table>

      <div class="text-center mt-4">
        @if($order->status === 'received_by_buyer')
          <a href="{{ route('guest.order.pdf.final', $order->token) }}" class="btn btn-dark" target="_blank">
            Unduh Bukti Pesanan Diterima
          </a>
        @else
          <a href="{{ route('guest.order.pdf', $order->token) }}" class="btn btn-outline-primary" target="_blank">
            Unduh Nota PDF
          </a>
        @endif

        @if($order->status === 'shipped_by_customer')
        <form method="POST" action="{{ route('guest.order.confirm', $order->token) }}" class="d-inline-block ml-3">
          @csrf
          @method('PATCH')
          <button type="submit" class="btn btn-success">
            Saya Sudah Menerima Pesanan
          </button>
        </form>
        @endif
      </div>
    </div>
  </div>
</div>
@endsection
