@extends('layouts.guest')

@section('content')
<div class="container mt-5 mb-5">
    <h2 class="mb-4 text-center">Keranjang Belanja</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @if(count($cart) > 0)
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @php $total = 0; @endphp
                @foreach($products as $product)
                    @php
                        $quantity = $cart[$product->id];
                        $subtotal = $product->price * $quantity;
                        $total += $subtotal;
                    @endphp
                    <tr>
                        <td>{{ $product->name }}</td>
                        <td>Rp{{ number_format($product->price) }}</td>
                        <td>{{ $quantity }}</td>
                        <td>Rp{{ number_format($subtotal) }}</td>
                        <td>
                            <a href="{{ route('cart.remove', $product->id) }}" class="btn btn-danger btn-sm">Hapus</a>
                        </td>
                    </tr>
                @endforeach
                <tr>
                    <td colspan="3" class="text-right"><strong>Total</strong></td>
                    <td colspan="2"><strong>Rp{{ number_format($total) }}</strong></td>
                </tr>
            </tbody>
        </table>

        <div class="text-center mt-4">
            <a href="{{ route('cart.clear') }}" class="btn btn-warning mr-2">Kosongkan Keranjang</a>
            <a href="{{ route('guest.checkout') }}" class="btn btn-primary">Lanjut ke Checkout</a>
        </div>
    @else
        <div class="alert alert-info text-center">Keranjang belanja Anda kosong.</div>
    @endif
</div>
@endsection
