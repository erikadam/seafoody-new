@extends('layouts.customer')

@section('content')
<div class="container mt-4">
    <h4>Daftar Pesanan Pembeli</h4>

    <table class="table table-bordered mt-3">
        <thead class="table-light">
            <tr>
                <th>Produk</th>
                <th>Pembeli</th>
                <th>Status</th>
                <th>Metode Bayar</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($order_items as $item)
                <tr>
                    <td>{{ $item->product->name }}</td>
                    <td>{{ $item->order->user->name }}</td>
                    <td>{{ $item->status }}</td>
                    <td>{{ strtoupper($item->order->payment_method) }}</td>
                    <td>
                        @if($item->status === 'accepted_by_admin')
                                <form action="{{ route('customer.orders.updateStatus', $item->id) }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="status" value="in_process_by_customer">
                                    <button class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm">Siapkan</button>
                                </form>

                            @elseif($item->status === 'in_process_by_customer')
                                <form action="{{ route('customer.orders.updateStatus', $item->id) }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="status" value="shipped_by_customer">
                                    <button class="bg-green-500 hover:bg-green-600 text-black px-3 py-1 rounded text-sm">Kirim</button>
                                </form>

                            @elseif($item->status === 'shipped_by_customer')
                                <span class="text-gray-500 text-sm">Menunggu Konfirmasi Pembeli</span>

                            @elseif($item->status === 'received_by_buyer')
                                <span class="text-green-600 font-semibold text-sm">Selesai</span>
                        @elseif($item->status === 'return_requested' && $item->order->payment_method === 'cash')
                            <form method="POST" action="{{ route('customer.refund.approve', $item->id) }}" style="display:inline">
                                @csrf
                                <button class="btn btn-sm btn-success">Setujui</button>
                            </form>
                            <form method="POST" action="{{ route('customer.refund.reject', $item->id) }}" style="display:inline">
                                @csrf
                                <button class="btn btn-sm btn-danger">Tolak</button>
                            </form>
                            @elseif($item->status === 'refunded' && $item->admin_transfer_proof)
    <a href="{{ asset('storage/' . $item->admin_transfer_proof) }}" target="_blank" class="btn btn-info btn-sm mb-1">Lihat Bukti Transfer</a>
    <form method="POST" action="{{ route('customer.refund.approve', $item->id) }}">
        @csrf
        <button class="btn btn-success btn-sm" onclick="return confirm('Setujui refund ini?')">Setujui Refund</button>
    </form>

                        @else
                            <span class="text-muted">-</span>
                        @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="text-center text-muted">Belum ada pesanan masuk.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
