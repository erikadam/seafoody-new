@extends('layouts.admin')

@section('content')
<div class="container py-4">
    <h2 class="text-2xl font-bold mb-4">Produk Menunggu Persetujuan</h2>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if($products->count() > 0)
        <table class="table-auto w-full bg-white shadow rounded-lg text-left">
            <thead class="bg-gray-100">
                <tr>
                    <th class="px-4 py-2 border-b">Nama Produk</th>
                    <th class="px-4 py-2 border-b">Harga</th>
                    <th class="px-4 py-2 border-b">Stok</th>
                    <th class="px-4 py-2 border-b">Penjual</th>
                    <th class="px-4 py-2 border-b">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($products as $product)
                    <tr class="border-t">
                        <td class="px-4 py-2">{{ $product->name }}</td>
                        <td class="px-4 py-2">Rp{{ number_format($product->price, 0, ',', '.') }}</td>
                        <td class="px-4 py-2">{{ $product->stock }}</td>
                        <td class="px-4 py-2">{{ $product->seller->name ?? '-' }}</td>
                        <td class="px-4 py-2 flex space-x-2">
                            <form action="{{ route('admin.products.approve', $product->id) }}" method="POST">
                                @csrf
                                <button class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">Setujui</button>
                            </form>
                            <form action="{{ route('admin.products.reject', $product->id) }}" method="POST">
                                @csrf
                                <button class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded text-sm">Tolak</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p class="text-gray-600">Tidak ada produk yang menunggu persetujuan.</p>
    @endif
</div>
@endsection
