@extends('layouts.customer')

@section('content')
  <h2>Produk Saya</h2>

  @if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
  @endif

  @if($products->count())
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Nama</th>
          <th>Deskripsi</th>
          <th>Harga</th>
          <th>Status</th>
          <th>Gambar</th>
        </tr>
      </thead>
      <tbody>
        @foreach($products as $product)
          <tr>
            <td>{{ $product->name }}</td>
            <td>{{ $product->description }}</td>
            <td>Rp {{ number_format($product->price) }}</td>
            <td>{{ $product->status ?? 'Menunggu Persetujuan' }}</td>
            <td>
              @if($product->image)
                <img src="{{ asset('storage/' . $product->image) }}" alt="" width="80">
              @else
                Tidak ada
              @endif
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  @else
    <p>Belum ada produk yang diunggah.</p>
  @endif
@endsection
